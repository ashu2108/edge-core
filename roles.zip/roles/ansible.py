import os
import sys
os.system(" sudo apt update ")
os.system(" sudo apt install software-properties-common ")
os.system(" sudo apt-add-repository ppa:ansible/ansible ")
os.system(" sudo apt update ")
os.system(" sudo apt install ansible ")
